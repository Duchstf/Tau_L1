//Numpy array shape [1]
//Min 0.023343238980
//Max 0.023343238980
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
model_default_t b8[1];
#else
model_default_t b8[1] = {0.02334324};
#endif

#endif
