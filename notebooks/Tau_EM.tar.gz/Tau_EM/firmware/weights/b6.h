//Numpy array shape [10]
//Min -0.936354994774
//Max 0.407682240009
//Number of zeros 0

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
model_default_t b6[10];
#else
model_default_t b6[10] = {-0.58549309, -0.06117089, -0.24173595, 0.17925857, -0.93635499, 0.18813914, 0.13134949, 0.04132507, 0.40768224, 0.29987794};
#endif

#endif
