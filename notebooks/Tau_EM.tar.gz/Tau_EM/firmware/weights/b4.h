//Numpy array shape [10]
//Min -0.380347400904
//Max 0.551839828491
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
model_default_t b4[10];
#else
model_default_t b4[10] = {0.55183983, 0.36323273, -0.13108490, -0.38034740, 0.08559006, 0.01700789, 0.13562575, -0.32752651, 0.48282012, -0.15096320};
#endif

#endif
