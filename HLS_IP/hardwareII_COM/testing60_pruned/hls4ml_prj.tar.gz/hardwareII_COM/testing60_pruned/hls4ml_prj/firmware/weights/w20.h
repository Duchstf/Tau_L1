//Numpy array shape [10, 1]
//Min -0.931640625000
//Max 1.476562500000
//Number of zeros 6

#ifndef W20_H_
#define W20_H_

#ifndef __SYNTHESIS__
weight20_t w20[10];
#else
weight20_t w20[10] = { 0.000000,  0.000000,  0.000000,  1.185547,  0.000000,  1.476562, -0.931641,  0.769531,  0.000000,  0.000000};
#endif

#endif
