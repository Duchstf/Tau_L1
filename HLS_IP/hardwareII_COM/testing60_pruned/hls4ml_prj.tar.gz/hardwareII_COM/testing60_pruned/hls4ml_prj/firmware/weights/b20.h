//Numpy array shape [1]
//Min 0.238281250000
//Max 0.238281250000
//Number of zeros 0

#ifndef B20_H_
#define B20_H_

#ifndef __SYNTHESIS__
bias20_t b20[1];
#else
bias20_t b20[1] = { 0.238281};
#endif

#endif
